<template>
  <div class="container-bottom">
    <div class="container">
      <div class="row">
        <div class="col text-center f-color font-size14">
          <span>Copyright © 2018 The Ontology Team</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'TheFooter'
  }
</script>

<style>
  .container-bottom {
    padding: 48px 0 10px;
  }
</style>
