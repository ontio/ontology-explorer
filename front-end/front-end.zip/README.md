# ont-explorer-frontEnd

> ONTology Explorer FrontEnd

## Build Setup

``` bash
# install dependencies
yarn install

# serve with hot reload at localhost:8080
yarn run dev

# build for production with minification
yarn run build
